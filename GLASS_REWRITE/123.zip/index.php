<?php
$md5 = md5($_SERVER['REQUEST_URI']);
$file = substr($md5, 0, 2) . '/' . substr($md5, 2, 2) . '/' . $md5 . '.html';
if (file_exists(__DIR__ . '/' . $file)) {
    echo file_get_contents(__DIR__ . '/' . $file);
    exit;
}

// lowcase
$md5 = md5(mb_strtolower($_SERVER['REQUEST_URI'], 'UTF-8'));
$file = substr($md5, 0, 2) . '/' . substr($md5, 2, 2) . '/' . $md5 . '.html';
if (file_exists(__DIR__ . '/' . $file)) {
    echo file_get_contents(__DIR__ . '/' . $file);
    exit;
}

// URL-decode
$md5 = md5(urldecode($_SERVER['REQUEST_URI']));
$file = substr($md5, 0, 2) . '/' . substr($md5, 2, 2) . '/' . $md5 . '.html';
if (file_exists(__DIR__ . '/' . $file)) {
    echo file_get_contents(__DIR__ . '/' . $file);
    exit;
}

header($_SERVER['SERVER_PROTOCOL'] .' 404 Not Found'); 